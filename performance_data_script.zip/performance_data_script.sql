USE [master]
GO
/****** Object:  Database [PerformanceData]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE DATABASE [PerformanceData]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'PerformanceData', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PerformanceData.mdf' , SIZE = 6082560KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'PerformanceData_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PerformanceData_log.ldf' , SIZE = 270336KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [PerformanceData] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PerformanceData].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [PerformanceData] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [PerformanceData] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [PerformanceData] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [PerformanceData] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [PerformanceData] SET ARITHABORT OFF 
GO
ALTER DATABASE [PerformanceData] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [PerformanceData] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [PerformanceData] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [PerformanceData] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [PerformanceData] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [PerformanceData] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [PerformanceData] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [PerformanceData] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [PerformanceData] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [PerformanceData] SET  ENABLE_BROKER 
GO
ALTER DATABASE [PerformanceData] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [PerformanceData] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [PerformanceData] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [PerformanceData] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [PerformanceData] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [PerformanceData] SET READ_COMMITTED_SNAPSHOT ON 
GO
ALTER DATABASE [PerformanceData] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [PerformanceData] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [PerformanceData] SET  MULTI_USER 
GO
ALTER DATABASE [PerformanceData] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [PerformanceData] SET DB_CHAINING OFF 
GO
ALTER DATABASE [PerformanceData] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [PerformanceData] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [PerformanceData] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [PerformanceData] SET QUERY_STORE = ON
GO
ALTER DATABASE [PerformanceData] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 100, QUERY_CAPTURE_MODE = ALL, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [PerformanceData]
GO
/****** Object:  User [sql_test]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE USER [sql_test] FOR LOGIN [sql_test] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [sql_test]
GO
/****** Object:  Table [dbo].[data_dates]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[data_dates](
	[srv] [varchar](128) NULL,
	[db] [nvarchar](128) NULL,
	[dt] [date] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[db_scope]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[db_scope](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[srv] [varchar](128) NULL,
	[db] [varchar](128) NULL,
	[instance] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[raw_db_resource_stats]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[raw_db_resource_stats](
	[record_date] [smalldatetime] NOT NULL,
	[srv] [varchar](128) NULL,
	[db] [nvarchar](128) NULL,
	[end_time] [datetime] NULL,
	[avg_cpu_percent] [numeric](5, 2) NULL,
	[avg_data_io_percent] [numeric](5, 2) NULL,
	[avg_log_write_percent] [numeric](5, 2) NULL,
	[avg_memory_usage_percent] [numeric](5, 2) NULL,
	[xtp_storage_percent] [numeric](5, 2) NULL,
	[max_worker_percent] [numeric](5, 2) NULL,
	[max_session_percent] [numeric](5, 2) NULL,
	[dtu_limit] [int] NULL,
	[avg_login_rate_percent] [numeric](5, 2) NULL,
	[avg_instance_cpu_percent] [numeric](5, 2) NULL,
	[avg_instance_memory_percent] [numeric](5, 2) NULL,
	[cpu_limit] [numeric](5, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[raw_db_wait_stats]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[raw_db_wait_stats](
	[record_date] [smalldatetime] NOT NULL,
	[srv] [varchar](128) NULL,
	[db] [nvarchar](128) NULL,
	[wait_type] [nvarchar](128) NOT NULL,
	[waiting_tasks_count] [bigint] NOT NULL,
	[wait_time_ms] [bigint] NOT NULL,
	[max_wait_time_ms] [bigint] NOT NULL,
	[signal_wait_time_ms] [bigint] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[raw_performance_counters]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[raw_performance_counters](
	[record_date] [smalldatetime] NOT NULL,
	[srv] [varchar](128) NULL,
	[db] [nvarchar](128) NULL,
	[object_name] [nchar](128) NOT NULL,
	[counter_name] [nchar](128) NOT NULL,
	[instance_name] [nchar](128) NULL,
	[cntr_value] [bigint] NOT NULL,
	[cntr_type] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[raw_resource_stats]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[raw_resource_stats](
	[record_date] [smalldatetime] NOT NULL,
	[srv] [varchar](128) NULL,
	[start_time] [datetime2](7) NOT NULL,
	[end_time] [datetime2](7) NOT NULL,
	[database_name] [nvarchar](128) NOT NULL,
	[sku] [nvarchar](128) NOT NULL,
	[storage_in_megabytes] [float] NULL,
	[avg_cpu_percent] [numeric](5, 2) NULL,
	[avg_data_io_percent] [numeric](5, 2) NULL,
	[avg_log_write_percent] [numeric](5, 2) NULL,
	[max_worker_percent] [numeric](5, 2) NULL,
	[max_session_percent] [numeric](5, 2) NULL,
	[dtu_limit] [int] NULL,
	[xtp_storage_percent] [numeric](5, 2) NULL,
	[avg_login_rate_percent] [numeric](5, 2) NULL,
	[avg_instance_cpu_percent] [numeric](5, 2) NULL,
	[avg_instance_memory_percent] [numeric](5, 2) NULL,
	[cpu_limit] [numeric](5, 2) NULL,
	[allocated_storage_in_megabytes] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[test]    Script Date: 12/31/2019 3:42:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[test](
	[id] [int] NULL,
	[name] [varchar](512) NULL
) ON [PRIMARY]
GO
/****** Object:  Index [idx_end_time_server]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE NONCLUSTERED INDEX [idx_end_time_server] ON [dbo].[raw_db_resource_stats]
(
	[end_time] ASC
)
INCLUDE([srv]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [idx_record_date]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE NONCLUSTERED INDEX [idx_record_date] ON [dbo].[raw_performance_counters]
(
	[record_date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [idx_end_time]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE NONCLUSTERED INDEX [idx_end_time] ON [dbo].[raw_resource_stats]
(
	[end_time] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [cci]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE CLUSTERED COLUMNSTORE INDEX [cci] ON [dbo].[raw_performance_counters] WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]
GO
/****** Object:  Index [cci]    Script Date: 12/31/2019 3:42:07 PM ******/
CREATE CLUSTERED COLUMNSTORE INDEX [cci] ON [dbo].[raw_resource_stats] WITH (DROP_EXISTING = OFF, COMPRESSION_DELAY = 0) ON [PRIMARY]
GO
ALTER TABLE [dbo].[raw_db_resource_stats] ADD  DEFAULT (getdate()) FOR [record_date]
GO
ALTER TABLE [dbo].[raw_db_wait_stats] ADD  DEFAULT (getdate()) FOR [record_date]
GO
ALTER TABLE [dbo].[raw_performance_counters] ADD  CONSTRAINT [DF_raw_performance_counters_record_date]  DEFAULT (getdate()) FOR [record_date]
GO
ALTER TABLE [dbo].[raw_resource_stats] ADD  DEFAULT (getdate()) FOR [record_date]
GO
USE [master]
GO
ALTER DATABASE [PerformanceData] SET  READ_WRITE 
GO
